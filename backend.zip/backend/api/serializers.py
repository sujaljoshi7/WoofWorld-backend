from rest_framework import serializers
from .models import Address, ContactDetails,ContactForm, ClientCompany, AboutUs, BlogCategory, Blog, BlogComment, WebinarCategory, Webinar, NewsCategory, News, NewsComment, ProductCategory, Products, ServiceCategory, Service
from django.utils import timezone


    
