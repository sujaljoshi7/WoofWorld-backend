from django.urls import path
from .views import get_user_data,get_all_users,get_specific_user_data,create_user_view, deactivate_user, activate_user, check_email


urlpatterns = [
    path("<int:user_id>/delete", deactivate_user, name="delete_user"),
    path("check-email/<str:email>/", check_email, name="check-email"),
    path("<int:user_id>/activate", activate_user, name="activate_user"),
    path('register/', create_user_view.as_view(), name='register'),
    path('all-users/', get_all_users, name='get_all_users'),
    path('get-user/<int:user_id>/', get_specific_user_data, name='get_all_users'),
    path('', get_user_data, name='get_user_data'),
]
